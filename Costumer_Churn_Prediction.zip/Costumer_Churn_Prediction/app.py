from flask import Flask, render_template, send_file
import os

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/download_graph/<graph_name>')
def download_graph(graph_name):
    # Path to the saved graph
    graph_path = os.path.join('graphs', f'{graph_name}.png')
    return send_file(graph_path)

if __name__ == '__main__':
    app.run(debug=True)
