import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
import pandas as pd

# Load the data (replace with the correct path to your dataset)
customer_data = pd.read_csv("Churn_Modelling.csv")  # Provide path to your data file

# Check for non-numeric columns and missing values
print(customer_data.info())

# Check for unique values in each column to see if any contain problematic strings
print(customer_data.nunique())

# Handle categorical columns 'Geography' and 'Gender' with One-Hot Encoding
# Replace non-numeric data with encoded values
customer_data = pd.get_dummies(customer_data, columns=['Geography', 'Gender'], drop_first=True)

# Handle any remaining non-numeric columns (if they exist) by converting them or removing
# For instance, 'Surname' can be dropped since it's non-numeric and irrelevant for prediction
customer_data = customer_data.drop(columns=['Surname'])

# Ensure the target column is 'Exited' and check for null values
if 'Exited' not in customer_data.columns:
    raise KeyError("'Exited' column not found in the dataset. Please ensure the target column exists.")

# Check for any missing values and handle them (e.g., fill with median or remove rows)
customer_data = customer_data.fillna(customer_data.median())  # Fill missing values with median

# Features and target
X = customer_data.drop('Exited', axis=1)  # Features
y = customer_data['Exited']  # Target variable (churn/exited)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Models
models = {
    'Logistic Regression': LogisticRegression(),
    'Random Forest': RandomForestClassifier(),
    'Gradient Boosting': GradientBoostingClassifier()
}

# Create the 'graphs' directory if it doesn't exist
if not os.path.exists('graphs'):
    os.makedirs('graphs')

# Model training and evaluation
for model_name, model in models.items():
    try:
        # Fit the model
        model.fit(X_train, y_train)
        
        # Predict using the model
        y_pred = model.predict(X_test)
        
        # Print model evaluation metrics
        print(f"Model: {model_name}")
        print(f"Accuracy: {accuracy_score(y_test, y_pred)}")
        print(f"Confusion Matrix: \n{confusion_matrix(y_test, y_pred)}")
        print(f"Classification Report: \n{classification_report(y_test, y_pred)}")
        
        # Save confusion matrix graph
        plt.figure(figsize=(8,6))
        plt.title(f'Confusion Matrix: {model_name}')
        sns.heatmap(confusion_matrix(y_test, y_pred), annot=True, cmap='Blues', fmt='g')
        plt.savefig(f'graphs/confusion_matrix_{model_name}.png')
        plt.close()
        
        # Plotting Feature Importance for RandomForest and GradientBoosting
        if model_name == 'Random Forest' or model_name == 'Gradient Boosting':
            feature_importance = model.feature_importances_
            plt.figure(figsize=(10,6))
            plt.barh(X.columns, feature_importance)
            plt.title(f'Feature Importance: {model_name}')
            plt.savefig(f'graphs/feature_importance_{model_name}.png')
            plt.close()
    
    except Exception as e:
        print(f"Error with {model_name}: {e}")
