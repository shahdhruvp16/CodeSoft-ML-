# save_graph.py
import matplotlib.pyplot as plt
import pandas as pd

# Load the dataset
df = pd.read_csv('data/spam.csv', encoding='latin-1')

# Preprocessing
df = df[['v1', 'v2']]
df.columns = ['label', 'message']

# Plot distribution of messages
plt.figure(figsize=(8, 6))
df['label'].value_counts().plot(kind='bar', color=['red', 'green'])
plt.title('SMS Spam vs Legitimate')
plt.xlabel('Message Type')
plt.ylabel('Count')
plt.xticks(ticks=[0, 1], labels=['Legitimate', 'Spam'], rotation=0)
plt.tight_layout()

# Save the plot to the 'graphs' folder
plt.savefig('graphs/analysis.png')
