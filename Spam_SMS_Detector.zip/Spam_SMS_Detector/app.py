# app.py
from flask import Flask, render_template, request
import pickle
import numpy as np

# Initialize the Flask application
app = Flask(__name__)

# Load the saved model and vectorizer
model = pickle.load(open('model.pkl', 'rb'))
vectorizer = pickle.load(open('vectorizer.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    message = request.form['message']  # Get SMS message from the form
    transformed_message = vectorizer.transform([message])  # Convert message to feature vector
    prediction = model.predict(transformed_message)  # Classify using the machine learning model

    result = 'Spam' if prediction[0] == 1 else 'Legitimate'  # Display result
    return render_template('index.html', prediction=result)

if __name__ == "__main__":
    app.run(debug=True)
